<!DOCTYPE html>
<html>
<head>
    <title>Page Not Found</title>
</head>
<body>
This is the custom 404 error page.
</body>
</html>
