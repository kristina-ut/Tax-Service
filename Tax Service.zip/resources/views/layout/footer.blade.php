<footer class="footer">
  <div class="container-fluid clearfix">
    <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright ©  <a href="https://jrptaxserviceinc.com/" target="_blank">jrptaxserviceinc.com</a> 2021</span>
    <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center"> <a href="https://jrptaxserviceinc.com/" target="_blank">Taxiservice</a> by jrptaxserviceinc.com <i class="mdi mdi-heart text-danger"></i>
    </span>
  </div>
</footer>