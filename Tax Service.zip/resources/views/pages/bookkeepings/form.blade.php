<div class="row">
    <div class="col-md-4"></div>
    <div class="form-group col-md-4">
    <input type="file" name="profile_files" class="form-control">
    </div>
</div>
<div class="row">
    <div class="col-md-4"></div>
    <div class="form-group col-md-4">
    <button type="submit" class="btn btn-success" style="margin-top:10px">Upload PDF</button>
    </div>
</div>
