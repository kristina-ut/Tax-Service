<div class="row mb-5">
    <input type="hidden" name="type" value="<?= $type ?>"/>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group align">
            <strong>111</strong>
           
            
        </div>
    </div>


    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group align">
            <strong>Status:</strong>
            
            
        </div>
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group align">
            <strong>Price:</strong>
            
            
        </div>
    </div>


    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div>
